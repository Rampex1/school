-- Include your INSERT SQL statements in this file.
-- Make sure to terminate each statement with a semicolon (;)

-- LEAVE this statement on. It is required to connect to your database.
CONNECT TO COMP421;

-- Remember to put the INSERT statements for the tables with foreign key references
--    ONLY AFTER the insert for the parent tables!

-- ============================================================
-- LoyaltyTier (no dependencies)
-- ============================================================
INSERT INTO LoyaltyTier (tierName, pointsThreshold, discountPercentage, specialBenefits) VALUES
('Bronze',   0,     0.00,  'Welcome gift, early check-in when available'),
('Silver',   1000,  5.00,  'Free breakfast on weekends, late checkout'),
('Gold',     5000,  10.00, 'Room upgrade when available, airport transfer'),
('Platinum', 15000, 15.00, 'Guaranteed suite upgrade, personal concierge, lounge access'),
('Diamond',  30000, 20.00, 'Dedicated butler, private airport transfers, guaranteed best available suite');

-- ============================================================
-- Customer (references LoyaltyTier) - 100 records
-- First 20: original records. Records 21-100 generated with Claude AI assistance
-- (see genai.pdf) using common French-Canadian and English-Canadian name lists.
-- ============================================================
INSERT INTO Customer (customerID, fName, lName, email, phoneNumber, dateOfBirth, registrationDate, loyaltyPoints, tierName) VALUES
(1,  'Emma',    'Thompson',  'emma.thompson@email.com',   '514-555-0101', '1985-03-14', '2022-01-15', 8750,  'Gold'),
(2,  'Liam',    'Nguyen',    'liam.nguyen@gmail.com',     '514-555-0102', '1990-07-22', '2022-03-20', 1200,  'Silver'),
(3,  'Sophia',  'Martinez',  'sophia.m@hotmail.com',      '438-555-0103', '1978-11-05', '2021-06-10', 22000, 'Platinum'),
(4,  'Noah',    'Patel',     'noah.patel@yahoo.com',      '514-555-0104', '1995-02-28', '2023-02-01', 400,   'Bronze'),
(5,  'Olivia',  'Chen',      'olivia.chen@email.com',     '438-555-0105', '1988-09-17', '2022-08-05', 3200,  'Silver'),
(6,  'William', 'Anderson',  'will.anderson@gmail.com',   '514-555-0106', '1970-12-30', '2020-11-12', 18500, 'Platinum'),
(7,  'Ava',     'Johnson',   'ava.j@outlook.com',         '438-555-0107', '1993-04-09', '2023-05-18', 700,   'Bronze'),
(8,  'James',   'Kim',       'james.kim@email.com',       '514-555-0108', '1982-08-25', '2021-09-30', 6400,  'Gold'),
(9,  'Isabella','Robinson',  'isabella.r@gmail.com',      '438-555-0109', '1997-01-14', '2024-01-20', 100,   'Bronze'),
(10, 'Oliver',  'Davis',     'oliver.davis@yahoo.com',    '514-555-0110', '1975-06-03', '2020-05-07', 12000, 'Gold'),
(11, 'Mia',     'Wilson',    'mia.wilson@email.com',      '514-555-0111', '1991-10-19', '2022-12-01', 2800,  'Silver'),
(12, 'Ethan',   'Garcia',    'ethan.garcia@gmail.com',    '438-555-0112', '1986-05-27', '2021-04-14', 9100,  'Gold'),
(13, 'Charlotte','Brown',    'charlotte.b@hotmail.com',   '514-555-0113', '1999-02-11', '2024-03-08', 50,    'Bronze'),
(14, 'Lucas',   'Taylor',    'lucas.taylor@email.com',    '438-555-0114', '1980-07-16', '2020-08-22', 16000, 'Platinum'),
(15, 'Amelia',  'Lee',       'amelia.lee@gmail.com',      '514-555-0115', '1994-12-07', '2023-07-11', 1800,  'Silver'),
(16, 'Henry',   'White',     'henry.white@outlook.com',   '438-555-0116', '1967-03-29', '2019-10-05', 25000, 'Platinum'),
(17, 'Harper',  'Harris',    'harper.h@email.com',        '514-555-0117', '1998-09-04', '2023-11-30', 300,   'Bronze'),
(18, 'Alexander','Clark',    'alex.clark@gmail.com',      '438-555-0118', '1983-01-21', '2021-07-19', 7200,  'Gold'),
(19, 'Evelyn',  'Lewis',     'evelyn.lewis@yahoo.com',    '514-555-0119', '1976-04-15', '2020-02-28', 11500, 'Gold'),
(20, 'Benjamin','Walker',    'ben.walker@email.com',      '438-555-0120', '2000-08-08', '2024-05-01', 150,   'Bronze'),
(21,  'Gabriel',    'Tremblay',    'g.tremblay@gmail.com',         '514-555-0121', '1987-06-15', '2022-04-10', 3400,  'Silver'),
(22,  'Sophie',     'Gagnon',      'sophie.gagnon@hotmail.com',    '418-555-0122', '1992-09-03', '2023-01-08', 650,   'Bronze'),
(23,  'Nicolas',    'Roy',         'nicolas.roy@email.com',        '514-555-0123', '1984-12-22', '2021-07-25', 7800,  'Gold'),
(24,  'Valerie',    'Cote',        'valerie.cote@gmail.com',       '438-555-0124', '1996-03-17', '2023-08-14', 200,   'Bronze'),
(25,  'Marc',       'Bouchard',    'marc.bouchard@outlook.com',    '514-555-0125', '1979-08-09', '2020-03-22', 12500, 'Gold'),
(26,  'Julie',      'Gauthier',    'julie.gauthier@email.com',     '418-555-0126', '1991-05-28', '2022-09-01', 2100,  'Silver'),
(27,  'Antoine',    'Morin',       'antoine.morin@gmail.com',      '438-555-0127', '1988-11-14', '2021-12-15', 6300,  'Gold'),
(28,  'Caroline',   'Lavoie',      'caroline.lavoie@hotmail.com',  '514-555-0128', '1974-07-31', '2019-06-18', 19500, 'Platinum'),
(29,  'Philippe',   'Fortin',      'philippe.fortin@email.com',    '418-555-0129', '1983-02-19', '2021-03-07', 4800,  'Silver'),
(30,  'Amelie',     'Lefebvre',    'amelie.lefebvre@gmail.com',    '514-555-0130', '1998-10-05', '2024-02-11', 80,    'Bronze'),
(31,  'Daniel',     'Ouellet',     'd.ouellet@email.com',          '438-555-0131', '1981-04-23', '2020-10-30', 9200,  'Gold'),
(32,  'Stephanie',  'Bergeron',    'steph.bergeron@gmail.com',     '514-555-0132', '1994-08-12', '2023-03-19', 1600,  'Silver'),
(33,  'Pierre',     'Pelletier',   'pierre.pelletier@outlook.com', '418-555-0133', '1969-01-07', '2018-09-14', 21000, 'Platinum'),
(34,  'Isabelle',   'Belanger',    'isa.belanger@email.com',       '438-555-0134', '1990-06-29', '2022-06-03', 3900,  'Silver'),
(35,  'Francois',   'Leblanc',     'francois.lb@gmail.com',        '514-555-0135', '1977-09-18', '2020-01-15', 11000, 'Gold'),
(36,  'Marie',      'Hebert',      'marie.hebert@hotmail.com',     '418-555-0136', '1986-03-04', '2021-08-22', 2700,  'Silver'),
(37,  'Jean',       'Charbonneau', 'jean.charbonneau@email.com',   '514-555-0137', '1972-12-11', '2019-04-28', 16500, 'Platinum'),
(38,  'Nathalie',   'Paquette',    'nat.paquette@gmail.com',       '438-555-0138', '1989-07-20', '2022-02-17', 4200,  'Silver'),
(39,  'Simon',      'Deschenes',   'simon.deschenes@email.com',    '514-555-0139', '1993-11-08', '2023-06-25', 900,   'Bronze'),
(40,  'Maxime',     'Girard',      'maxime.girard@gmail.com',      '418-555-0140', '1985-04-16', '2021-05-10', 8100,  'Gold'),
(41,  'Sarah',      'Mitchell',    'sarah.mitchell@email.com',     '416-555-0141', '1992-08-25', '2022-07-14', 1300,  'Silver'),
(42,  'Ryan',       'Campbell',    'ryan.campbell@gmail.com',      '416-555-0142', '1987-01-30', '2021-11-20', 5500,  'Gold'),
(43,  'Jessica',    'Parker',      'jessica.parker@hotmail.com',   '416-555-0143', '1995-06-08', '2023-04-05', 450,   'Bronze'),
(44,  'Tyler',      'Evans',       'tyler.evans@email.com',        '613-555-0144', '1982-10-22', '2020-08-17', 13500, 'Gold'),
(45,  'Megan',      'Edwards',     'megan.edwards@gmail.com',      '613-555-0145', '1991-03-14', '2022-10-29', 2400,  'Silver'),
(46,  'Brandon',    'Nelson',      'brandon.nelson@outlook.com',   '416-555-0146', '1979-09-05', '2019-12-03', 17800, 'Platinum'),
(47,  'Lauren',     'Phillips',    'lauren.phillips@email.com',    '613-555-0147', '1996-02-17', '2023-09-12', 750,   'Bronze'),
(48,  'Justin',     'Roberts',     'justin.roberts@gmail.com',     '416-555-0148', '1984-07-28', '2021-02-06', 6900,  'Gold'),
(49,  'Amanda',     'Turner',      'amanda.turner@hotmail.com',    '613-555-0149', '1989-12-01', '2022-05-18', 3100,  'Silver'),
(50,  'Kyle',       'Baker',       'kyle.baker@email.com',         '416-555-0150', '1997-05-19', '2024-01-07', 120,   'Bronze'),
(51,  'Rebecca',    'Scott',       'rebecca.scott@gmail.com',      '416-555-0151', '1980-11-23', '2020-07-14', 14200, 'Gold'),
(52,  'Zachary',    'Green',       'zachary.green@email.com',      '613-555-0152', '1993-04-07', '2023-02-28', 1900,  'Silver'),
(53,  'Emily',      'Adams',       'emily.adams@gmail.com',        '416-555-0153', '1986-08-15', '2021-09-05', 7400,  'Gold'),
(54,  'Nathan',     'Gonzalez',    'nathan.gonzalez@hotmail.com',  '613-555-0154', '1975-02-28', '2019-05-21', 24000, 'Platinum'),
(55,  'Ashley',     'Carter',      'ashley.carter@email.com',      '416-555-0155', '1990-06-11', '2022-03-16', 2900,  'Silver'),
(56,  'Austin',     'Hall',        'austin.hall@gmail.com',        '613-555-0156', '1998-09-29', '2024-03-01', 30,    'Bronze'),
(57,  'Hannah',     'Young',       'hannah.young@email.com',       '416-555-0157', '1983-01-18', '2020-11-08', 10800, 'Gold'),
(58,  'Joshua',     'King',        'joshua.king@gmail.com',        '613-555-0158', '1994-07-04', '2023-05-22', 500,   'Bronze'),
(59,  'Katherine',  'Wright',      'kate.wright@hotmail.com',      '416-555-0159', '1977-10-30', '2019-08-13', 18200, 'Platinum'),
(60,  'Dylan',      'Lopez',       'dylan.lopez@email.com',        '613-555-0160', '1992-03-22', '2022-12-19', 3600,  'Silver'),
(61,  'Rachel',     'Allen',       'rachel.allen@gmail.com',       '604-555-0161', '1988-05-14', '2021-06-07', 5900,  'Gold'),
(62,  'Christopher','Hill',        'chris.hill@email.com',         '604-555-0162', '1981-09-27', '2020-04-25', 9800,  'Gold'),
(63,  'Michelle',   'Moore',       'michelle.moore@gmail.com',     '604-555-0163', '1995-01-09', '2023-07-18', 1100,  'Silver'),
(64,  'Matthew',    'Jackson',     'matthew.jackson@hotmail.com',  '604-555-0164', '1970-12-03', '2018-06-30', 32000, 'Diamond'),
(65,  'Nicole',     'Harris',      'nicole.harris@email.com',      '604-555-0165', '1987-06-21', '2021-10-14', 4500,  'Silver'),
(66,  'Andrew',     'Martin',      'andrew.martin@gmail.com',      '604-555-0166', '1976-04-08', '2019-03-22', 22000, 'Platinum'),
(67,  'Elizabeth',  'Thomson',     'liz.thomson@email.com',        '604-555-0167', '1993-08-17', '2022-08-30', 2200,  'Silver'),
(68,  'Robert',     'Williams',    'robert.williams@gmail.com',    '604-555-0168', '1984-02-14', '2021-01-19', 8700,  'Gold'),
(69,  'Jennifer',   'Brown',       'jennifer.brown@hotmail.com',   '604-555-0169', '1990-11-05', '2022-04-12', 3300,  'Silver'),
(70,  'Michael',    'Smith',       'michael.smith@email.com',      '604-555-0170', '1978-07-22', '2020-02-09', 13800, 'Gold'),
(71,  'Chloe',      'Mercier',     'chloe.mercier@gmail.com',      '514-555-0171', '1999-03-11', '2024-04-20', 60,    'Bronze'),
(72,  'Alexis',     'Poirier',     'alexis.poirier@email.com',     '438-555-0172', '1986-10-28', '2021-11-03', 6700,  'Gold'),
(73,  'Dominique',  'Rousseau',    'dom.rousseau@gmail.com',       '514-555-0173', '1973-05-19', '2018-12-15', 27000, 'Platinum'),
(74,  'Laurie',     'Fontaine',    'laurie.fontaine@hotmail.com',  '418-555-0174', '1994-12-07', '2023-10-28', 800,   'Bronze'),
(75,  'Julien',     'Dubois',      'julien.dubois@email.com',      '514-555-0175', '1989-08-03', '2022-01-25', 4100,  'Silver'),
(76,  'Sandrine',   'Beaulieu',    'sandrine.b@gmail.com',         '438-555-0176', '1982-02-16', '2020-09-14', 11500, 'Gold'),
(77,  'Thomas',     'Leger',       'thomas.leger@email.com',       '514-555-0177', '1991-06-30', '2022-07-07', 2800,  'Silver'),
(78,  'Veronique',  'Dion',        'veronique.dion@gmail.com',     '418-555-0178', '1985-11-21', '2021-04-16', 7100,  'Gold'),
(79,  'Patrick',    'Malo',        'patrick.malo@hotmail.com',     '514-555-0179', '1968-04-08', '2018-02-28', 29500, 'Platinum'),
(80,  'Emilie',     'Simard',      'emilie.simard@email.com',      '438-555-0180', '1997-09-14', '2023-12-01', 350,   'Bronze'),
(81,  'Charles',    'Lebrun',      'charles.lebrun@gmail.com',     '514-555-0181', '1983-07-25', '2021-05-20', 9400,  'Gold'),
(82,  'Genevieve',  'Cloutier',    'gen.cloutier@email.com',       '418-555-0182', '1990-03-12', '2022-09-08', 1700,  'Silver'),
(83,  'Mathieu',    'Audet',       'mathieu.audet@gmail.com',      '438-555-0183', '1987-12-04', '2021-08-31', 5200,  'Gold'),
(84,  'Roxanne',    'Bernard',     'roxanne.bernard@hotmail.com',  '514-555-0184', '1996-05-26', '2023-06-15', 550,   'Bronze'),
(85,  'Sebastien',  'Renaud',      'sebastien.renaud@email.com',   '418-555-0185', '1979-08-18', '2019-11-22', 16000, 'Platinum'),
(86,  'Pascale',    'Desrochers',  'pascale.d@gmail.com',          '514-555-0186', '1992-01-29', '2022-03-04', 3700,  'Silver'),
(87,  'Kevin',      'MacDonald',   'kevin.macdonald@email.com',    '416-555-0187', '1985-04-14', '2021-07-11', 8300,  'Gold'),
(88,  'Brittany',   'Sullivan',    'brittany.sullivan@gmail.com',  '416-555-0188', '1993-09-07', '2023-01-30', 1400,  'Silver'),
(89,  'Derek',      'O''Connor',   'derek.oconnor@hotmail.com',    '416-555-0189', '1980-06-22', '2020-05-18', 12000, 'Gold'),
(90,  'Tiffany',    'Patterson',   'tiffany.p@email.com',          '613-555-0190', '1995-11-15', '2023-08-27', 280,   'Bronze'),
(91,  'Gregory',    'Morrison',    'greg.morrison@gmail.com',      '416-555-0191', '1977-03-09', '2019-09-05', 20500, 'Platinum'),
(92,  'Vanessa',    'Fleming',     'vanessa.fleming@email.com',    '613-555-0192', '1988-07-17', '2022-02-23', 4600,  'Silver'),
(93,  'Curtis',     'Barrett',     'curtis.barrett@gmail.com',     '416-555-0193', '1983-10-31', '2021-03-12', 6200,  'Gold'),
(94,  'Melissa',    'Fitzgerald',  'melissa.fitz@hotmail.com',     '613-555-0194', '1991-02-06', '2022-10-01', 2500,  'Silver'),
(95,  'Trevor',     'Gallagher',   'trevor.gallagher@email.com',   '416-555-0195', '1976-08-24', '2019-07-16', 15500, 'Platinum'),
(96,  'Shannon',    'Walsh',       'shannon.walsh@gmail.com',      '613-555-0196', '1998-04-13', '2024-02-05', 90,    'Bronze'),
(97,  'Aaron',      'Burke',       'aaron.burke@email.com',        '416-555-0197', '1986-12-19', '2021-06-28', 7600,  'Gold'),
(98,  'Crystal',    'Brennan',     'crystal.brennan@gmail.com',    '613-555-0198', '1994-05-08', '2023-04-16', 1000,  'Silver'),
(99,  'Spencer',    'Mahon',       'spencer.mahon@hotmail.com',    '416-555-0199', '1971-11-27', '2018-04-09', 35000, 'Diamond'),
(100, 'Victoria',   'Chambers',    'victoria.chambers@email.com',  '613-555-0200', '1989-08-02', '2022-11-14', 2600,  'Silver');

-- ============================================================
-- Hotel (no dependencies) - 5 hotels
-- ============================================================
INSERT INTO Hotel (hotelID, hotelName, street, city, stateProvince, country, postalCode, starRating, phoneNumber, email, totalRooms, checkInTime, checkOutTime, propertyType) VALUES
(1, 'Grand Palais Montreal',     '1228 Sherbrooke St W', 'Montreal',  'Quebec',  'Canada', 'H3G 1H6', 5, '514-842-4212', 'info@grandpalais.ca',     120, '15:00:00', '11:00:00', 'Luxury'),
(2, 'Le Meridien Downtown',      '750 Peel Street',      'Montreal',  'Quebec',  'Canada', 'H3C 3H4', 4, '514-879-1370', 'info@lemeridien.ca',      200, '14:00:00', '12:00:00', 'Business'),
(3, 'Auberge du Plateau',        '3523 St Laurent Blvd', 'Montreal',  'Quebec',  'Canada', 'H2X 2V1', 3, '514-285-0404', 'stay@auberge-plateau.ca', 45,  '15:00:00', '11:00:00', 'Boutique'),
(4, 'Chateau Frontenac Quebec',  '1 Rue des Carrieres',  'Quebec City','Quebec', 'Canada', 'G1R 4P5', 5, '418-692-3861', 'frontenac@fairmont.ca',   611, '16:00:00', '12:00:00', 'Historic'),
(5, 'Toronto Harbor Inn',        '1 Harbour Square',     'Toronto',   'Ontario', 'Canada', 'M5J 1A6', 4, '416-869-1600', 'info@torontoharbor.ca',   350, '15:00:00', '11:00:00', 'Resort');

-- ============================================================
-- RoomType (references Hotel) - 5 types per hotel (25 total)
-- ============================================================
INSERT INTO RoomType (hotelID, typeName, description, maxOccupancy, bedConfiguration, sizeInSqMeters, basePricePerNight) VALUES
(1, 'Standard Single',    'Comfortable single room with city view',              1, '1 Queen',          22.0, 189.00),
(1, 'Deluxe Double',      'Spacious double room with premium furnishings',       2, '1 King',            32.0, 289.00),
(1, 'Executive Suite',    'Business suite with lounge and work area',            2, '1 King + Sofa',     55.0, 489.00),
(1, 'Presidential Suite', 'Two-bedroom luxury suite with panoramic views',      4, '2 Kings',          110.0, 989.00),
(1, 'Junior Suite',       'Entry-level suite with separate living area',        2, '1 King',            45.0, 389.00),
(2, 'Standard Single',    'Modern single room near business district',          1, '1 Queen',           20.0, 149.00),
(2, 'Deluxe Double',      'Twin queen room ideal for couples or colleagues',    2, '2 Queens',          30.0, 229.00),
(2, 'Executive Suite',    'Fully equipped suite for business travelers',        2, '1 King + Sofa',     50.0, 399.00),
(2, 'Junior Suite',       'Comfortable suite with separate sleeping area',      2, '1 King',            40.0, 299.00),
(2, 'Conference Room',    'Suite with attached meeting facilities',             4, '1 King',            70.0, 549.00),
(3, 'Standard Single',    'Cozy single with Montreal Plateau character',        1, '1 Double',          18.0,  99.00),
(3, 'Deluxe Double',      'Romantic double with exposed brick walls',           2, '1 Queen',           25.0, 159.00),
(3, 'Family Suite',       'Spacious suite for families up to 4 guests',         4, '1 King + 2 Twins',  45.0, 249.00),
(3, 'Penthouse',          'Rooftop suite with private terrace',                 2, '1 King',            60.0, 349.00),
(3, 'Budget Single',      'Affordable option with shared common areas',         1, '1 Twin',            14.0,  79.00),
(4, 'Standard Single',    'Classic chateau-style single room',                  1, '1 Queen',           24.0, 219.00),
(4, 'Deluxe Double',      'Double room with castle architecture details',       2, '1 King',            35.0, 319.00),
(4, 'Executive Suite',    'Spacious suite with St Lawrence River view',         2, '1 King + Sofa',     60.0, 519.00),
(4, 'Presidential Suite', 'Grand suite with antique furnishings and river view',4, '2 Kings',          130.0,1099.00),
(4, 'Fairmont Room',      'Signature room with iconic chateau aesthetic',       2, '1 King',            38.0, 359.00),
(5, 'Standard Single',    'Lake view single with modern amenities',             1, '1 Queen',           21.0, 169.00),
(5, 'Deluxe Double',      'Harbor-facing room with premium bedding',            2, '1 King',            33.0, 259.00),
(5, 'Executive Suite',    'Business suite with boardroom and lake view',        2, '1 King + Sofa',     58.0, 459.00),
(5, 'Presidential Suite', 'Waterfront luxury suite with private balcony',       4, '2 Kings',          115.0,1049.00),
(5, 'Family Suite',       'Child-friendly suite with bunk beds and play area',  4, '1 King + Bunks',    65.0, 399.00);

-- ============================================================
-- Room (references Hotel, RoomType) - 10 rooms per hotel (50 total)
-- ============================================================
INSERT INTO Room (roomID, roomNumber, floorNumber, roomStatus, hotelID, typeName) VALUES
-- Hotel 1 rooms
(101, '101', 1, 'available',   1, 'Standard Single'),
(102, '102', 1, 'available',   1, 'Standard Single'),
(103, '201', 2, 'available',   1, 'Deluxe Double'),
(104, '202', 2, 'occupied',    1, 'Deluxe Double'),
(105, '301', 3, 'available',   1, 'Executive Suite'),
(106, '302', 3, 'maintenance', 1, 'Executive Suite'),
(107, '401', 4, 'available',   1, 'Junior Suite'),
(108, '501', 5, 'available',   1, 'Junior Suite'),
(109, '601', 6, 'available',   1, 'Presidential Suite'),
(110, '602', 6, 'occupied',    1, 'Presidential Suite'),
-- Hotel 2 rooms
(201, '101', 1, 'available',   2, 'Standard Single'),
(202, '102', 1, 'occupied',    2, 'Standard Single'),
(203, '201', 2, 'available',   2, 'Deluxe Double'),
(204, '202', 2, 'available',   2, 'Deluxe Double'),
(205, '301', 3, 'occupied',    2, 'Executive Suite'),
(206, '302', 3, 'available',   2, 'Executive Suite'),
(207, '401', 4, 'available',   2, 'Junior Suite'),
(208, '402', 4, 'maintenance', 2, 'Junior Suite'),
(209, '501', 5, 'available',   2, 'Conference Room'),
(210, '502', 5, 'available',   2, 'Conference Room'),
-- Hotel 3 rooms
(301, '1A',  1, 'available',   3, 'Standard Single'),
(302, '1B',  1, 'available',   3, 'Budget Single'),
(303, '2A',  2, 'occupied',    3, 'Deluxe Double'),
(304, '2B',  2, 'available',   3, 'Deluxe Double'),
(305, '3A',  3, 'available',   3, 'Family Suite'),
(306, '3B',  3, 'available',   3, 'Family Suite'),
(307, '4A',  4, 'available',   3, 'Penthouse'),
(308, '1C',  1, 'available',   3, 'Budget Single'),
(309, '2C',  2, 'available',   3, 'Standard Single'),
(310, '3C',  3, 'maintenance', 3, 'Family Suite'),
-- Hotel 4 rooms
(401, '101', 1, 'available',   4, 'Standard Single'),
(402, '102', 1, 'available',   4, 'Standard Single'),
(403, '201', 2, 'available',   4, 'Deluxe Double'),
(404, '202', 2, 'occupied',    4, 'Fairmont Room'),
(405, '301', 3, 'available',   4, 'Executive Suite'),
(406, '302', 3, 'available',   4, 'Executive Suite'),
(407, '401', 4, 'occupied',    4, 'Fairmont Room'),
(408, '501', 5, 'available',   4, 'Presidential Suite'),
(409, '502', 5, 'available',   4, 'Presidential Suite'),
(410, '203', 2, 'available',   4, 'Deluxe Double'),
-- Hotel 5 rooms
(501, '101', 1, 'available',   5, 'Standard Single'),
(502, '102', 1, 'available',   5, 'Standard Single'),
(503, '201', 2, 'available',   5, 'Deluxe Double'),
(504, '202', 2, 'occupied',    5, 'Deluxe Double'),
(505, '301', 3, 'available',   5, 'Executive Suite'),
(506, '401', 4, 'available',   5, 'Presidential Suite'),
(507, '402', 4, 'available',   5, 'Presidential Suite'),
(508, '501', 5, 'available',   5, 'Family Suite'),
(509, '502', 5, 'occupied',    5, 'Family Suite'),
(510, '102', 1, 'available',   5, 'Family Suite');

-- ============================================================
-- Reservation (references Customer) - 20 reservations
-- ============================================================
INSERT INTO Reservation (reservationID, checkInDate, checkOutDate, numberOfGuests, totalPrice, bookingDate, reservationStatus, specialRequests, cancellationPolicyType, customerID) VALUES
(1001, '2026-01-10', '2026-01-14', 2, 1156.00, '2025-12-20', 'completed',   'High floor preferred',         'flexible',     1),
(1002, '2026-01-15', '2026-01-17', 1,  298.00, '2026-01-02', 'completed',   NULL,                            'standard',    2),
(1003, '2026-02-01', '2026-02-07', 4, 5934.00, '2026-01-10', 'completed',   'Anniversary setup please',      'flexible',    3),
(1004, '2026-02-14', '2026-02-16', 2,  578.00, '2026-02-01', 'completed',   'Valentine flowers in room',     'standard',    4),
(1005, '2026-02-20', '2026-02-25', 2, 1445.00, '2026-02-10', 'completed',   NULL,                            'standard',    5),
(1006, '2026-03-01', '2026-03-05', 2, 1556.00, '2026-02-15', 'confirmed',   'Late check-in after 11pm',      'flexible',    6),
(1007, '2026-03-10', '2026-03-12', 1,  198.00, '2026-02-28', 'confirmed',   NULL,                            'non-refundable', 7),
(1008, '2026-03-15', '2026-03-20', 2, 1995.00, '2026-03-01', 'confirmed',   'Extra pillows',                 'standard',    8),
(1009, '2026-03-18', '2026-03-21', 1,  447.00, '2026-03-02', 'confirmed',   NULL,                            'standard',    9),
(1010, '2026-03-22', '2026-03-26', 4, 2196.00, '2026-03-05', 'confirmed',   'Adjoining rooms if possible',   'flexible',    10),
(1011, '2026-04-01', '2026-04-05', 2, 1596.00, '2026-03-10', 'confirmed',   NULL,                            'standard',    11),
(1012, '2026-04-10', '2026-04-15', 2, 1295.00, '2026-03-15', 'confirmed',   'Gluten-free breakfast',         'standard',    12),
(1013, '2026-04-20', '2026-04-22', 1,  338.00, '2026-03-20', 'pending',     NULL,                            'non-refundable', 13),
(1014, '2026-05-01', '2026-05-07', 4, 6594.00, '2026-04-01', 'confirmed',   'Executive lounge access',       'flexible',    14),
(1015, '2026-05-15', '2026-05-18', 2,  897.00, '2026-04-20', 'confirmed',   NULL,                            'standard',    15),
(1016, '2026-01-05', '2026-01-10', 2, 4945.00, '2025-12-15', 'completed',   'Penthouse with champagne',      'flexible',    16),
(1017, '2026-02-25', '2026-02-27', 1,  338.00, '2026-02-15', 'cancelled',   NULL,                            'standard',    17),
(1018, '2026-03-05', '2026-03-10', 2, 3600.00, '2026-02-20', 'confirmed',   'River view essential',          'flexible',    18),
(1019, '2026-03-12', '2026-03-14', 2, 5198.00, '2026-03-01', 'confirmed',   NULL,                            'standard',    19),
(1020, '2026-04-05', '2026-04-07', 1,  338.00, '2026-03-25', 'pending',     'Early check-in requested',      'non-refundable', 20);

-- ============================================================
-- ReservationRoom (references Reservation and Room)
-- ============================================================
INSERT INTO ReservationRoom (reservationID, roomID, pricePerNight) VALUES
(1001, 103, 289.00),
(1002, 201, 149.00),
(1003, 110, 989.00),
(1004, 102, 189.00),
(1005, 205, 399.00),
(1006, 404, 359.00),
(1007, 302, 79.00),
(1008, 106, 399.00),
(1009, 401, 219.00),
(1010, 404, 359.00),
(1010, 403, 319.00),
(1011, 207, 299.00),
(1012, 503, 259.00),
(1013, 301, 99.00),
(1014, 408, 1099.00),
(1015, 507, 299.00),
(1016, 307, 349.00),
(1017, 303, 159.00),
(1018, 405, 519.00),
(1019, 506, 1049.00),
(1019, 507, 1049.00),
(1020, 302, 99.00);

-- ============================================================
-- Payment (references Reservation)
-- ============================================================
INSERT INTO Payment (paymentID, paymentDate, amount, paymentMethod, transactionID, paymentStatus, reservationID) VALUES
(5001, '2025-12-20', 1156.00, 'credit_card', 'TXN-CC-100201', 'completed', 1001),
(5002, '2026-01-02',  298.00, 'debit_card',  'TXN-DC-100202', 'completed', 1002),
(5003, '2026-01-10', 5934.00, 'credit_card', 'TXN-CC-100203', 'completed', 1003),
(5004, '2026-02-01',  578.00, 'paypal',      'TXN-PP-100204', 'completed', 1004),
(5005, '2026-02-10', 1445.00, 'credit_card', 'TXN-CC-100205', 'completed', 1005),
(5006, '2026-02-15', 1556.00, 'credit_card', 'TXN-CC-100206', 'completed', 1006),
(5007, '2026-02-28',  198.00, 'debit_card',  'TXN-DC-100207', 'completed', 1007),
(5008, '2026-03-01', 1995.00, 'credit_card', 'TXN-CC-100208', 'completed', 1008),
(5009, '2026-03-02',  447.00, 'credit_card', 'TXN-CC-100209', 'completed', 1009),
(5010, '2026-03-05', 2196.00, 'wire_transfer','TXN-WT-100210', 'completed', 1010),
(5011, '2026-03-10', 1596.00, 'credit_card', 'TXN-CC-100211', 'pending',   1011),
(5012, '2026-03-15', 1295.00, 'credit_card', 'TXN-CC-100212', 'pending',   1012),
(5013, '2026-03-20',  338.00, 'debit_card',  'TXN-DC-100213', 'pending',   1013),
(5014, '2026-04-01', 6594.00, 'wire_transfer','TXN-WT-100214', 'pending',   1014),
(5015, '2026-04-20',  897.00, 'credit_card', 'TXN-CC-100215', 'pending',   1015),
(5016, '2025-12-15', 4945.00, 'credit_card', 'TXN-CC-100216', 'completed', 1016),
(5017, '2026-02-15',  338.00, 'debit_card',  'TXN-DC-100217', 'refunded',  1017),
(5018, '2026-02-20', 3600.00, 'credit_card', 'TXN-CC-100218', 'completed', 1018),
(5019, '2026-03-01', 5198.00, 'wire_transfer','TXN-WT-100219', 'completed', 1019),
(5020, '2026-03-25',  338.00, 'paypal',      'TXN-PP-100220', 'pending',   1020);

-- ============================================================
-- Review (references Customer and Hotel)
-- ============================================================
INSERT INTO Review (reviewID, rating, reviewText, reviewDate, cleanlinessRating, locationRating, serviceRating, valueRating, flaggedForModeration, customerID, hotelID) VALUES
(2001, 5, 'Absolutely magnificent stay. The staff were attentive and the room exceeded all expectations.',            '2026-01-15', 5, 4, 5, 4, 'N', 1, 1),
(2002, 4, 'Great location for business travel. Clean rooms and fast WiFi.',                                           '2026-01-18', 4, 5, 4, 4, 'N', 2, 2),
(2003, 5, 'The presidential suite was unbelievable. Perfect for our anniversary.',                                    '2026-02-08', 5, 4, 5, 4, 'N', 3, 1),
(2004, 3, 'Decent hotel but the room was smaller than expected. Good location though.',                               '2026-02-17', 3, 5, 3, 3, 'N', 4, 3),
(2005, 4, 'Nice executive suite. Business amenities were top-notch.',                                                 '2026-02-26', 4, 5, 4, 4, 'N', 5, 2),
(2006, 5, 'The penthouse at Auberge was spectacular. Best boutique hotel experience in Montreal.',                    '2026-01-12', 5, 5, 5, 5, 'N', 16, 3),
(2007, 4, 'Wonderful historic atmosphere at Chateau Frontenac. Views of the river are breathtaking.',                '2026-03-08', 4, 5, 4, 3, 'N', 8, 4),
(2008, 5, 'Toronto Harbor Inn delivered on every promise. Waterfront views are stunning.',                            '2026-03-22', 5, 5, 5, 4, 'N', 10, 5),
(2009, 2, 'Room was not ready upon arrival and staff seemed overwhelmed. Disappointing.',                             '2026-03-04', 2, 4, 2, 3, 'N', 9, 2),
(2010, 4, 'Excellent service and spotless rooms. Would highly recommend for family stays.',                           '2026-02-28', 5, 4, 4, 4, 'N', 11, 5),
(2011, 5, 'Grand Palais lives up to its name. Pure luxury from check-in to check-out.',                              '2026-03-22', 5, 4, 5, 4, 'N', 12, 1),
(2012, 3, 'Average stay. Nothing special but nothing bad.',                                                           '2026-04-16', 3, 3, 3, 3, 'N', 15, 3),
(2013, 5, 'The presidential suite at Chateau Frontenac is a bucket-list experience.',                                '2026-05-08', 5, 5, 5, 4, 'N', 14, 4),
(2014, 4, 'Great amenities and comfortable beds. Will return for sure.',                                              '2026-03-15', 4, 4, 4, 4, 'N', 18, 4),
(2015, 5, 'Waterfront presidential suite was worth every penny.',                                                     '2026-03-15', 5, 5, 5, 5, 'N', 19, 5);

-- ============================================================
-- Staff (references Hotel) - 10 staff members
-- ============================================================
INSERT INTO Staff (staffID, fName, lName, email, phoneNumber, hireDate, salary, employmentStatus, hotelID) VALUES
(3001, 'Marie',    'Tremblay',   'marie.tremblay@grandpalais.ca',    '514-555-3001', '2018-03-01', 72000.00, 'active',     1),
(3002, 'Jean',     'Beaumont',   'jean.beaumont@grandpalais.ca',     '514-555-3002', '2020-06-15', 55000.00, 'active',     1),
(3003, 'Patrick',  'Gagnon',     'p.gagnon@lemeridien.ca',           '514-555-3003', '2019-09-10', 61000.00, 'active',     2),
(3004, 'Claudine', 'Leblanc',    'c.leblanc@lemeridien.ca',          '514-555-3004', '2021-01-20', 48000.00, 'active',     2),
(3005, 'Stephane', 'Bouchard',   'sbouchard@auberge-plateau.ca',     '514-555-3005', '2017-05-12', 42000.00, 'active',     3),
(3006, 'Nathalie', 'Côté',       'ncote@auberge-plateau.ca',         '514-555-3006', '2022-08-01', 38000.00, 'on_leave',   3),
(3007, 'François', 'Lavoie',     'flavoie@frontenac.ca',             '418-555-3007', '2016-02-28', 80000.00, 'active',     4),
(3008, 'Isabelle', 'Moreau',     'imoreau@frontenac.ca',             '418-555-3008', '2019-11-15', 65000.00, 'active',     4),
(3009, 'Michael',  'O''Brien',   'mobrien@torontoharbor.ca',         '416-555-3009', '2018-07-01', 68000.00, 'active',     5),
(3010, 'Sarah',    'MacDonald',  'smacdonald@torontoharbor.ca',      '416-555-3010', '2020-03-15', 52000.00, 'active',     5);

-- ============================================================
-- Service (references Hotel) - 5+ services
-- ============================================================
INSERT INTO Service (serviceID, serviceName, description, price, durationMinutes, availabilityStatus, hotelID) VALUES
(4001, 'Deep Tissue Massage',  'Full body therapeutic massage',            120.00, 60,  'available',   1),
(4002, 'Airport Transfer',     'Private car service to/from airport',       85.00, NULL,'available',   1),
(4003, 'Room Service Dining',  '24-hour in-room dining from hotel kitchen', 45.00, NULL,'available',   1),
(4004, 'Business Center',      'Meeting room rental with AV equipment',    200.00, 120, 'available',   2),
(4005, 'Dry Cleaning',         'Same-day dry cleaning and pressing',        35.00, NULL,'available',   2),
(4006, 'Guided City Tour',     'Half-day guided tour of Montreal',          75.00, 240, 'available',   3),
(4007, 'Bike Rental',          'City e-bike rental for exploring Plateau',  25.00, NULL,'available',   3),
(4008, 'Horse-Drawn Carriage', 'Classic Old Quebec carriage tour',          60.00, 45,  'available',   4),
(4009, 'Spa Package',          'Full day spa including facial and massage', 250.00, 480, 'available',  4),
(4010, 'Yacht Charter',        'Private yacht tour of Toronto Harbor',     500.00, 240, 'available',  5),
(4011, 'Fitness Training',     'Personal trainer session in hotel gym',     95.00, 60,  'available',  5),
(4012, 'Hot Stone Massage',    'Relaxing hot stone therapy',               140.00, 75,  'unavailable', 1);

-- ============================================================
-- Amenity (no dependencies)
-- ============================================================
INSERT INTO Amenity (amenityID, amenityName, description) VALUES
(6001, 'WiFi',            'High-speed wireless internet throughout property'),
(6002, 'Parking',         'On-site covered parking with valet option'),
(6003, 'Pool',            'Heated indoor/outdoor swimming pool'),
(6004, 'Gym',             'State-of-the-art fitness center'),
(6005, 'Business Center', 'Fully equipped business center with meeting rooms'),
(6006, 'Restaurant',      'On-site restaurant serving local and international cuisine'),
(6007, 'Bar',             'Lobby bar and lounge area'),
(6008, 'Pet Friendly',    'Pets welcome with advance notice'),
(6009, 'Spa',             'Full-service spa and wellness center'),
(6010, 'Concierge',       '24-hour concierge service');

-- ============================================================
-- HotelAmenity (references Hotel and Amenity)
-- ============================================================
INSERT INTO HotelAmenity (hotelID, amenityID) VALUES
(1, 6001),(1, 6002),(1, 6003),(1, 6004),(1, 6005),(1, 6006),(1, 6007),(1, 6009),(1, 6010),
(2, 6001),(2, 6002),(2, 6004),(2, 6005),(2, 6006),(2, 6007),(2, 6010),
(3, 6001),(3, 6006),(3, 6007),(3, 6008),
(4, 6001),(4, 6002),(4, 6003),(4, 6004),(4, 6006),(4, 6007),(4, 6009),(4, 6010),
(5, 6001),(5, 6002),(5, 6003),(5, 6004),(5, 6005),(5, 6006),(5, 6007),(5, 6008),(5, 6009),(5, 6010);
